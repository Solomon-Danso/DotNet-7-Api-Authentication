using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace FlexiSecure.Data
{
    public class DataContext : DbContext
    {

        //Construtor 
       public DataContext(DbContextOptions<DataContext> options) : base(options){}

        //Connection Strings 
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder){
            base.OnConfiguring(optionsBuilder);

            optionsBuilder.UseSqlServer("Server=localhost,1433;Database=FlexiApiDb;User=sa;Password=HydotTech;TrustServerCertificate=true;");
        }



        //Data sets 
       public DbSet<User> Users => Set<User>();


    }
}